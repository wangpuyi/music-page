import { reactive } from 'vue'

export const store = reactive({
  count: 0,
  song_to_check:"hi",
  
})
