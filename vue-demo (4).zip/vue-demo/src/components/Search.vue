<script>
import { update } from 'lodash'
import { store } from '../store.js'
export default {
  data() {
    return {
      msg: 'Music'
      ,
      store,
      refresh:true
    }
  },
  methods:{
    send_search(){
      
      this.$router.push('/B')
      store.update++
  
}}}
</script>

<template>
<div class="bottom"> 
  <input v-model="store.song_to_check" >
  <comp v-if="refresh"></comp>
  <button @click="send_search "  >搜索</button>



</div>

  
</template>
<style lang="less" scoped>



</style>
