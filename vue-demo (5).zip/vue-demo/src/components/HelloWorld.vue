<template>
  <div style="width:2000px; display: table;">
    <div class="pop" v-if="showModal">
        <button @click="showModal=false" class="btn">{{ pick_tag }}</button>
        <br>
        <br>
        <br>
        <br>
        <a style="float:left" href="">全部歌单</a>
        <br>
        <br>
        <div style="width:1000px; display: table;">
          <div style="display: table-cell;;width: 100px;;">
            <p style="float:left">语种</p>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">华语</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">欧美</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">日语</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">韩语</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">粤语</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href=""></a>
          </div>
        </div>
        <br>
        <div style="width:1000px; display: table;">
          <div style="display: table-cell;;width: 100px;;">
            <p style="float:left">风格</p>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">流行</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">摇滚</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">民谣</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">电子</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">舞曲</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">说唱</a>
          </div>
        </div>
        <br>
        <div style="width:1000px; display: table;">
          <div style="display: table-cell;;width: 100px;;">
            <p style="float:left"></p>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">轻音乐</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">爵士</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">乡村</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">R&B/Soul</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">古典</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">民族</a>
          </div>
        </div>
        <br>
        <div style="width:1000px; display: table;">
          <div style="display: table-cell;;width: 100px;;">
            <p style="float:left"></p>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">英伦</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">金属</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">朋克</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">蓝调</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">雷鬼</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">世界音乐</a>
          </div>
        </div>
        <br>
        <div style="width:1000px; display: table;">
          <div style="display: table-cell;;width: 100px;;">
            <p style="float:left"></p>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">拉丁</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">New Age</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">古风</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">后摇</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">Bossa Nova</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">说唱</a>
          </div>
        </div>
        <br>
        <div style="width:1000px; display: table;">
          <div style="display: table-cell;;width: 100px;;">
            <p style="float:left">场景</p>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">清晨</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">夜晚</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">学习</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">工作</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">午休</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">下午茶</a>
          </div>
        </div>
        <br>
        <div style="width:1000px; display: table;">
          <div style="display: table-cell;;width: 100px;;">
            <p style="float:left"></p>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">地铁</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">驾车</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">运动</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">旅行</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">散步</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">酒吧</a>
          </div>
        </div>
        <br>
        <div style="width:1000px; display: table;">
          <div style="display: table-cell;;width: 100px;;">
            <p style="float:left">情感</p>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">怀旧</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">清新</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">浪漫</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">伤感</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">治愈</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">放松</a>
          </div>
        </div>
        <br>
        <div style="width:1000px; display: table;">
          <div style="display: table-cell;;width: 100px;;">
            <p style="float:left"></p>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">孤独</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">感动</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">兴奋</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">快乐</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">安静</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">思念</a>
          </div>
        </div>
        <br>
        <div style="width:1000px; display: table;">
          <div style="display: table-cell;;width: 100px;;">
            <p style="float:left">主题</p>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">综艺</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">影视原声</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">ACG</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">儿童</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">校园</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">游戏</a>
          </div>
        </div>
        <br>
        <div style="width:1000px; display: table;">
          <div style="display: table-cell;;width: 100px;;">
            <p style="float:left"></p>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">70后</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">80后</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">90后</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">网络歌曲</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">KTV</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">经典</a>
          </div>
        </div>
        <br>
        <div style="width:1000px; display: table;">
          <div style="display: table-cell;;width: 100px;;">
            <p style="float:left"></p>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">翻唱</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">吉他</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">钢琴</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">器乐</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">榜单</a>
          </div>
          <div style="display: table-cell;;width: 100px;;">
            <a style="float:left" href="">00后</a>
          </div>
        </div>
      </div>
      <button @click="showModal=true" class="btn">{{ pick_tag }}</button>
    </div>
  
  <div>
    <div style="width:2000px; display: table;">
      <div style="display: table-cell;;width: 200px;height: 500px">
        <img class="img" src='../../pictures/微信图片_20221213105151.png' />
        <p class="font12 color-363636">宝藏雷达 | 惊喜总出现于不经意间</p>
      </div>
      <div style="display: table-cell;;width: 200px;height: 500px">
        <img class="img" src='../../pictures/微信图片_20221213105240.png'/>
        <p class="font12 color-363636">[徒步随响]深秋轨迹，在路途中找答案</p>
      </div>
      <div style="display: table-cell;;width: 200px;height: 500px">
        <img class="img" src='../../pictures/微信图片_20221213105243.png'/>
        <p class="font12 color-363636">[听·莫文蔚] 慢慢喜欢你，从这首歌起</p>
      </div>
      <div style="display: table-cell;;width: 200px;height: 500px">
        <img class="img" src='../../pictures/微信图片_20221213105247.png'/>
        <p class="font12 color-363636">[华语节奏布鲁斯] 情绪辗转反侧 雾气消散不开</p>
      </div>
    </div>
    <div style="width:2000px; display: table;">
      <div style="display: table-cell;;width: 200px;height: 500px">
        <img class="img" src='../../pictures/微信图片_20221213105250.png'/>
        <p class="font12 color-363636">[真实说唱派] 让歌里的故事诉说心事</p>
      </div>
      <div style="display: table-cell;;width: 200px;height: 500px">
        <img class="img" src='../../pictures/微信图片_20221213105253.png'/>
        <p class="font12 color-363636">[国风嘻哈] 独步武林 肝胆相照</p>
      </div>
      <div style="display: table-cell;;width: 200px;height: 500px">
        <img class="img" src='../../pictures/微信图片_20221213105257.png'/>
        <p class="font12 color-363636">[华语私人订制] 最懂你的华语推荐 每日更新35首</p>
      </div>
      <div style="display: table-cell;;width: 200px;height: 500px">
        <img class="img" src='../../pictures/微信图片_20221213105301.png'/>
        <p class="font12 color-363636">[EDM Progressive House] 感受电音正能量</p>
      </div>
    </div>
  </div>
</template>

<script>

export default {
  data() {
    return {
      showModal: false,
      pick_tag: "华语"
    };
  }
};
</script>

<style scoped>
.mask {
  background-color: #000;
  opacity: 0.3;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 1
}
.pop {
  background-color: #fff;
 
  position: fixed;
  top: 200px;
  left: 50px;
  width: 1000px;
  height:1000px;
  z-index: 9999
}
.btn {
  background-color: #fff;
  border-radius: 4px;
  border: 1px solid rgb(0, 0, 0);
  padding: 20px 24px;
  position: fixed;
  top: 300px;
  left:50px;
  z-index: 999;
}
</style>